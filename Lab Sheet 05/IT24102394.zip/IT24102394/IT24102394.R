setwd("C:\\Users\\User\\Desktop\\IT24102394")

#1
Delivery_Times <- read.table ("Exercise - Lab 05.txt",header = TRUE, sep = ",")
fix(Delivery_Times)

#2
names(Delivery_Times) <- c("X1")
attach(Delivery_Times)

histogram<-hist(X1,main = "Histogram for Delivary Time",breaks = seq(20,70,length = 10),right=FALSE)

#3
#Approximately symmetric and bell-shaped

#4
breaks<- round(histogram$breaks)
freq<-histogram$counts
mids<-histogram$mids

cum.freq <-cumsum(freq)

new <- c()

for (i in 1: length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i] = cum.freq[i-1]
  }
}

plot(breaks, new,
     type = "l",
     main = "Frequency polygon for Delivary Time",
     xlab = "X1",
     ylab = "Frequency",
     ylim = c(0,max(cum.freq)))
